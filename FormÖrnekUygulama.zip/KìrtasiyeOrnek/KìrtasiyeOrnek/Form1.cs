﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KırtasiyeOrnek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static int a = 0;
        public static int b = 0;

        private void listStok_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnÇıkar.Enabled = true;
            btnEkle.Enabled = false;
            if (a == 0)
            {
                txtSeçilenTutar.Text = listStok.SelectedItem.ToString().Substring(listStok.SelectedItem.ToString().Length - 8);
            }
            else
            {
                txtSeçilenTutar.Clear();
                a = 0;
            }
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (listTedarikçi.Items.Count == 0)
            {
                return;
            }
            b = 1;
            if (!(listStok.Items.Contains(listTedarikçi.SelectedItem.ToString())))
            {
                listStok.Items.Add(listTedarikçi.SelectedItem.ToString());
            }
            listTedarikçi.Items.Remove(listTedarikçi.SelectedItem.ToString());
        }

        private void btnÇıkar_Click(object sender, EventArgs e)
        {
            if (listStok.Items.Count == 0)
            {
                return;
            }
            a = 1;
            if (!(listTedarikçi.Items.Contains(listStok.SelectedItem.ToString())))
            {
                listTedarikçi.Items.Add(listStok.SelectedItem.ToString());
            }
            listStok.Items.Remove(listStok.SelectedItem.ToString());
        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            if (listStok.Items.Count == 0)
            {
                return;
            }
            double sayı = 0;
            foreach (string item in listStok.Items)
            {
                sayı += Convert.ToDouble(item.Substring(item.Length - 8,5));
            }
            txtToplam.Text = sayı.ToString()+" Tl";
        }

        private void listTedarikçi_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnÇıkar.Enabled = false;
            btnEkle.Enabled = true;
            if (b == 0)
            {
                txtSeçilenTutar.Text = listTedarikçi.SelectedItem.ToString().Substring(listTedarikçi.SelectedItem.ToString().Length - 8);
            }
            else
            {
                txtSeçilenTutar.Clear();
                b = 0;
            }
        }
    }
}
