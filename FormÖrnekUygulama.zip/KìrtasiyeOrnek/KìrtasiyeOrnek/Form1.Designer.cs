﻿namespace KırtasiyeOrnek
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.listTedarikçi = new System.Windows.Forms.ListBox();
            this.listStok = new System.Windows.Forms.ListBox();
            this.btnEkle = new System.Windows.Forms.Button();
            this.btnÇıkar = new System.Windows.Forms.Button();
            this.btnHesapla = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSeçilenTutar = new System.Windows.Forms.TextBox();
            this.txtToplam = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // listTedarikçi
            // 
            this.listTedarikçi.BackColor = System.Drawing.Color.Red;
            this.listTedarikçi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listTedarikçi.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listTedarikçi.FormattingEnabled = true;
            this.listTedarikçi.ItemHeight = 29;
            this.listTedarikçi.Items.AddRange(new object[] {
            "Defter - 4,99 TL",
            "Cetvel- 1,99 TL",
            "Pergel - 2,99 TL"});
            this.listTedarikçi.Location = new System.Drawing.Point(30, 59);
            this.listTedarikçi.Name = "listTedarikçi";
            this.listTedarikçi.Size = new System.Drawing.Size(306, 232);
            this.listTedarikçi.TabIndex = 0;
            this.listTedarikçi.SelectedIndexChanged += new System.EventHandler(this.listTedarikçi_SelectedIndexChanged);
            // 
            // listStok
            // 
            this.listStok.BackColor = System.Drawing.Color.Red;
            this.listStok.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listStok.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listStok.FormattingEnabled = true;
            this.listStok.ItemHeight = 29;
            this.listStok.Items.AddRange(new object[] {
            "Kalem - 1,49 TL",
            "Silgi - 0,39 TL",
            "Not Defteri - 3,79 TL"});
            this.listStok.Location = new System.Drawing.Point(569, 59);
            this.listStok.Name = "listStok";
            this.listStok.Size = new System.Drawing.Size(306, 232);
            this.listStok.TabIndex = 1;
            this.listStok.SelectedIndexChanged += new System.EventHandler(this.listStok_SelectedIndexChanged);
            // 
            // btnEkle
            // 
            this.btnEkle.BackColor = System.Drawing.Color.Transparent;
            this.btnEkle.Enabled = false;
            this.btnEkle.FlatAppearance.BorderSize = 3;
            this.btnEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnEkle.Location = new System.Drawing.Point(384, 59);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(141, 42);
            this.btnEkle.TabIndex = 2;
            this.btnEkle.Text = "EKLE >>>";
            this.btnEkle.UseVisualStyleBackColor = false;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // btnÇıkar
            // 
            this.btnÇıkar.BackColor = System.Drawing.Color.Transparent;
            this.btnÇıkar.Enabled = false;
            this.btnÇıkar.FlatAppearance.BorderSize = 3;
            this.btnÇıkar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnÇıkar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnÇıkar.Location = new System.Drawing.Point(384, 154);
            this.btnÇıkar.Name = "btnÇıkar";
            this.btnÇıkar.Size = new System.Drawing.Size(141, 42);
            this.btnÇıkar.TabIndex = 3;
            this.btnÇıkar.Text = "<<< ÇIKAR";
            this.btnÇıkar.UseVisualStyleBackColor = false;
            this.btnÇıkar.Click += new System.EventHandler(this.btnÇıkar_Click);
            // 
            // btnHesapla
            // 
            this.btnHesapla.BackColor = System.Drawing.Color.Transparent;
            this.btnHesapla.FlatAppearance.BorderSize = 3;
            this.btnHesapla.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHesapla.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnHesapla.Location = new System.Drawing.Point(384, 249);
            this.btnHesapla.Name = "btnHesapla";
            this.btnHesapla.Size = new System.Drawing.Size(141, 42);
            this.btnHesapla.TabIndex = 4;
            this.btnHesapla.Text = "HESAPLA";
            this.btnHesapla.UseVisualStyleBackColor = false;
            this.btnHesapla.Click += new System.EventHandler(this.btnHesapla_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(546, 317);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Seçilen Ürünler :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(546, 358);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Toplam :";
            // 
            // txtSeçilenTutar
            // 
            this.txtSeçilenTutar.BackColor = System.Drawing.Color.Chartreuse;
            this.txtSeçilenTutar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSeçilenTutar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSeçilenTutar.Location = new System.Drawing.Point(680, 310);
            this.txtSeçilenTutar.Name = "txtSeçilenTutar";
            this.txtSeçilenTutar.Size = new System.Drawing.Size(195, 23);
            this.txtSeçilenTutar.TabIndex = 7;
            // 
            // txtToplam
            // 
            this.txtToplam.BackColor = System.Drawing.Color.Chartreuse;
            this.txtToplam.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtToplam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtToplam.Location = new System.Drawing.Point(680, 351);
            this.txtToplam.Name = "txtToplam";
            this.txtToplam.Size = new System.Drawing.Size(195, 23);
            this.txtToplam.TabIndex = 8;
            this.txtToplam.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(942, 493);
            this.Controls.Add(this.txtToplam);
            this.Controls.Add(this.txtSeçilenTutar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnHesapla);
            this.Controls.Add(this.btnÇıkar);
            this.Controls.Add(this.btnEkle);
            this.Controls.Add(this.listStok);
            this.Controls.Add(this.listTedarikçi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listTedarikçi;
        private System.Windows.Forms.ListBox listStok;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.Button btnÇıkar;
        private System.Windows.Forms.Button btnHesapla;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSeçilenTutar;
        private System.Windows.Forms.TextBox txtToplam;
    }
}

