﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _210542009
{
    
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            byte sayac = 0;
            Random rndy = new Random();
            int y;
            int[,] labirent = new int[8,8];
            Labirent lab = new Labirent();
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {

                    try
                    {
                        if ((i == 0 && j == 0)|| (i == 7 && j == 7))
                        {
                            labirent[i, j] = 0;             
                        }
                        else
                        {
                            labirent[i, j] = 1;
                        }
                    }
                    catch (IndexOutOfRangeException ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                }
            }
            
            for (int i = 0; i < 8; i++)
            {
                for (;;)
                {
                    if (i == 7 && a == 7)
                    {
                        break;
                    }
                    else
                    {
                        y = (int)rndy.Next(1, 4);
                        // 1 saga git
                        // 2 asagı git
                        // 3 çapraz git
                        switch (y)
                        {
                            case (1):
                                if (a == 7)
                                {
                                    goto case (2);
                                }
                                labirent[i, a + 1] = lab.sagGit();
                                a++;
                                break;

                            case (2):
                                if (i == 7)
                                {
                                    goto case (1);
                                }
                                else
                                {
                                    labirent[i + 1, a] = lab.asagıGit();
                                    i++;
                                }
                                break;
                            case (3):
                                if (i == 7)
                                {
                                    goto case (1);
                                    
                                }
                                else if(a == 7)
                                {
                                    goto case (2);
                                }
                                labirent[i + 1, a + 1] = lab.sagCaprazGit();
                                i++;
                                a++;
                                break;
                        }
                    }
                    
                }
            }
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (labirent[i,j] == 0)
                    {
                        sayac++;
                    }
                    Console.Write(labirent[i, j] + " ");
                }
                Console.WriteLine(" ");
            }


            Console.WriteLine("\n\nUzunluk = {0}",sayac);

            Console.WriteLine("\n\n210542009 Saffet Demir");
            Console.ReadLine();
        }
    }
}