﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _210542009
{
    internal class Labirent
    {
        public Labirent()
        {
        
        }
        public int sagGit()
        {
            return 0;
        }
        public int asagıGit()
        {
            return 0;
        }
        public int sagCaprazGit()
        {
            return 0;
        }
    }
}  