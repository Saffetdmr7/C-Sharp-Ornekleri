﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dizisonelemanısıfıryapma
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dizi = { 0, 5, 4,0,8,7,41,-1,5,0,0,47,0,0,0, 8, 2, 5, 0 };
            Array.Sort(dizi);
            Array.Reverse(dizi);
            for (int i = 0; i < dizi.Length; i++)
            {
                if (dizi[i] == 0)
                {
                    for (int j = i; j < dizi.Length; j++)
                    {
                        if (dizi[j] != 0)
                        {
                            int temp = dizi[j];
                            dizi[j] = dizi[i];
                            dizi[i] = temp;
                        }
                    }
                }
                
            }
            foreach (int item in dizi)
            {
                Console.Write(item);
            }
            Console.ReadLine();
        } 
    }

}
