﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarmaşıkSayı
{
    // Operator overloading 
    // @author Saffetdmr7
    internal class KarmasıkSayıOlusturma
    {
        private int gercek;
        private int sanal;
        public KarmasıkSayıOlusturma(int gercek,int sanal) {
            this.gercek = gercek;
            this.sanal = sanal;
        }
        public KarmasıkSayıOlusturma() {
            gercek = 0;
            sanal = 0;
        }
        public void yazdır() {
            if (sanal!=0)
            {
                Console.WriteLine("Gercek = {0:d}\nSanal = {1:d}i",gercek,sanal);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Gerçek = {0:d}",gercek);
                Console.WriteLine();
            }
        
        }
        public static KarmasıkSayıOlusturma operator +(KarmasıkSayıOlusturma a,KarmasıkSayıOlusturma b)
        {
            int gercekToplam = a.gercek + b.gercek;
            int sanalToplam = a.sanal + b.sanal;
            return new KarmasıkSayıOlusturma(gercekToplam,sanalToplam);

        }
        public static KarmasıkSayıOlusturma operator +(KarmasıkSayıOlusturma a
            , int b)
        {
            int gt = a.gercek + b;
            return new KarmasıkSayıOlusturma(gt, a.sanal);

        }

        public static KarmasıkSayıOlusturma operator +(int a, KarmasıkSayıOlusturma b)
        {
            return b + a;
        }

        public static KarmasıkSayıOlusturma operator -(KarmasıkSayıOlusturma a,KarmasıkSayıOlusturma b) {
            int gercekFark = a.gercek - b.gercek;
            int sanalFark = a.sanal - b.sanal;
            return new KarmasıkSayıOlusturma(gercekFark, sanalFark);
        }
        public static KarmasıkSayıOlusturma operator *(KarmasıkSayıOlusturma a,KarmasıkSayıOlusturma b) {
            int gercekCarpım = a.gercek * b.gercek;
            int sanalCarpım = a.sanal * b.sanal;
            return new KarmasıkSayıOlusturma(gercekCarpım, sanalCarpım);
        }
        public static KarmasıkSayıOlusturma operator /(KarmasıkSayıOlusturma a,KarmasıkSayıOlusturma b) {
            int gercekCarpım = 0;
            int sanalCarpım = 0;
            if ((a.gercek % b.gercek == 0) && (a.sanal % b.sanal == 0))
            {
                gercekCarpım = a.gercek / b.gercek;
                sanalCarpım = a.sanal / b.sanal;
            }
            else
            {
                Console.WriteLine("Bölünemez");
            }
            return new KarmasıkSayıOlusturma(gercekCarpım, sanalCarpım);
        }
        public static bool operator ==(KarmasıkSayıOlusturma a,KarmasıkSayıOlusturma b) {
            if (a.gercek == b.gercek && a.sanal == b.sanal)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator !=(KarmasıkSayıOlusturma a,KarmasıkSayıOlusturma b) {
            return !(a == b);
        }
    }
}
