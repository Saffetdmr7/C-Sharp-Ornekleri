﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarmaşıkSayı
{
    internal class Program
    {
        static void Main(string[] args)
        {
            KarmasıkSayıOlusturma sayi1 = new KarmasıkSayıOlusturma(5,-5);
            sayi1.yazdır();
            KarmasıkSayıOlusturma t = 10 + sayi1;
            t.yazdır();
            KarmasıkSayıOlusturma y = sayi1 + 7;
            y.yazdır();
            KarmasıkSayıOlusturma z = sayi1 + sayi1;
            z.yazdır();
            //KarmasıkSayıOlusturma sayi2 = new KarmasıkSayıOlusturma(5,-5);
            //sayi2.yazdır();
            //KarmasıkSayıOlusturma a =  sayi1 + sayi2;
            //a.yazdır();
            //a = sayi1 / sayi2;
            //a.yazdır();
            //a = sayi1 - sayi2;
            //a.yazdır();
            //a = sayi1 * sayi2;
            //a.yazdır();
            //if (sayi1 == sayi2)
            //{
            //    Console.WriteLine("Eşittir");
            //}
            //else
            //{
            //    Console.WriteLine("Eşit Değil");
            //}
            Console.ReadKey();
        }
    }
}
