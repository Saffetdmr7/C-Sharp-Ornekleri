﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Nesne_Tabanlı_Programlama_Slaytlar
{
    internal class ikinciSlayt
    {
     
        static void Main(string[] args)
        {
            OgrenciEkleSil.Islemler();
            
            
            //Program pro = new Program();
            //pro.Olustur();
            //KrediHesabi hesap1 = new KrediHesabi();
            //KrediHesabi hesap2 = new KrediHesabi();
            //hesap1.HesapNo = 3456;
            //hesap2.HesapNo = 1111;
            //Console.WriteLine(hesap1.HesapNo);
            //Console.WriteLine(hesap2.HesapNo);
            //ornekler1();
            //ornekler2();
            //ornekler3();
            //ornekler4();
            //ornekler5();//unboxingte doğru dönüşümün önemi bu örnekte
            //ornekler6();
            //Dortgen.dondur();
            //Dortgen1.dondur();
            //Dortgen2.dondur();
            //ornekler7();
            //ornekler8();
            //ornekler9();
            //ornekler10();
            //ornekler11();
            //ornekler12();
            //ornekler13();
            //ornekler15();
            ///*ornekler16();//asal sayılar aralıktaki*/
            ///*ornekler17();*///tamsayıların ikilik tabandaki karşılığı
            //ornekler18();
            //ornekler19();
            //ornekler20();
            //ornekler21();
            //int[] dizi = { 1, 3, 2, 5, 6, 4 };
            //ornekler22(dizi);
            //yazdegistir.degistir(dizi);
            //yazdegistir.yaz(dizi);
            //int i = 10000;
            //yazdegistir2.degistir(ref i);
            //yazdegistir2.yaz(i);
            //ornekler23();
            //ornekler24();
            //ornekler25();
            //ornekler26();
            Console.ReadLine();
        }
        public static void ornekler1()//varsayılan değerleri döndürür
        {
            bool a = new bool(); byte a1 = new byte();
            char a2 = new char(); decimal a3 = new decimal();
            double a4 = new double();float a5 = new float();
            Console.WriteLine(a); Console.WriteLine(a1);
            Console.WriteLine(a2); Console.WriteLine(a3);
            Console.WriteLine(a4); Console.WriteLine(a5);
            Console.ReadLine();
        }
        public static void ornekler2()
        {
            object a;
            a = 10;
            Console.WriteLine(a.GetType());
            a = "8";
            Console.WriteLine(a.GetType());
            a = 8.76f;
            Console.WriteLine(a.GetType());
            a = false;
            Console.WriteLine(a.GetType());
            a = 8.756M;
            Console.WriteLine(a.GetType());
            Console.ReadLine();

        }//Tipleri döndürür
        public static void ornekler3()
        {
                        double d1, d2; int i; byte b; char c; uint u; short s; d1 = 5.0; d2 = 4.0;
             //double int e dönüştü veri kaybı var,virgülden sonrası atılır
             i = (int)(d1 / d2); Console.WriteLine("Double integere çevrildi=" + i); Console.WriteLine();
             //int'i byte dönüştür, Veri kaybı yok.
             i = 123; b = (byte)i; Console.WriteLine("i'nin değeri=" + i + " iken b'nin değeri=" + b);
             //Veri kaybı var.
             i = 258; b = (byte)i; Console.WriteLine("i'nin değeri=" + i + " iken b'nin değeri=" + b);
             Console.WriteLine();
             //uint'i short'a dönüştür
              u = 32146; s = (short)u; //Veri kaybı yok.
             Console.WriteLine("u'nun değeri=" + u + " iken s'nin değeri=" + s);
             u = 35000; s = (short)u; //Veri kaybı var.
             Console.WriteLine("u'nun değeri=" + u + " iken s'nin değeri=" + s); Console.WriteLine();
             //int'i char'a dönüştür.
            i = 90; c = (char)i; Console.WriteLine(i + "sayısının char'a dönüştürürsek=" + c + " olur");
            Console.ReadLine();
        }//veri kaybı kontrolü
        public static void ornekler4()
        {
            int a = 5;
            int b = 7;
            string a1 = a.ToString();
            string b1 = b.ToString();
            Console.WriteLine(a + b);
            Console.WriteLine(a1 + b1);
            Console.ReadLine();
        }// string ve int da + operatörü
        public static void ornekler5()//boxing unboxing
        {
            int i = 10;
            object o = i;

            String a = (String)o;
            Console.WriteLine(i);
            Console.WriteLine(a);
            Console.ReadLine();
        }
        public static void ornekler6()//ikili for döngüsü
        {
            for (int i = 0, j = 0; i < 20; i++, j++)
            {
                i *= j;
                Console.WriteLine("i = " + i + " j = " + j);
            }
            Console.ReadLine();
        }
        public static void ornekler7() {
            int a = 400;
            byte b = (byte)a;
            Console.WriteLine(b);
        }//ikilik dönüşüm veri kaybı
        public static void ornekler8()//checked ve unchecked
        {
            int a = 255;
            int b = 500;
            byte c, d;
            checked
            {
                c = (byte)a;
                Console.WriteLine(c);
                unchecked
                {
                    d = (byte)b;
                    Console.WriteLine(d);
                }
            }
        }
        public static void ornekler9()//tür dönüşümü
        {
            string a = "1789";
            String B = "211";
            Console.WriteLine(Convert.ToInt32(a)+Convert.ToInt32(B));
        }
        public static void ornekler10()// tekli mantık operatörleri(& | ^)
        {
             bool a = true;
             bool b = false;
             if (a ^ b) Console.WriteLine("a^b doğrudur");
             if (a && b) Console.WriteLine("a ve b doğrudur");
             if (a || b) Console.WriteLine("a veya b doğrudur");
        }
        public static void ornekler11() // tümleme
        {
             byte b1 = 254;
             byte b2 = (byte)~b1;
             Console.WriteLine(b2);
        }
        public static void ornekler12() // tekli operatörler devamı
        {
             int x = 195;
             int y = 26;
             x = x ^ y;
            y = y ^ x;
            x = x ^ y;
            Console.WriteLine("x={0}\ny={1}", x, y);
        }
        public static void ornekler13() // bit kaydırma metodu
        {
             byte b = 0xFF; //255
             b = (byte)(b << 4);
             Console.WriteLine(b); //240
             b = (byte)(b >> 3);
             Console.WriteLine(b); //30

        }
        public static void ornekler15() // bir sayıya kadar ardışık seri oluşturma
        {
            int i = 0,a,n;
            Console.WriteLine("Bir sayı giriniz : ");
            n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Artım Miktarı : ");
            a = Convert.ToInt32(Console.ReadLine());

            for (; i < n;)
            {
                Console.Write("{0} ",i);
                i += a;
            }
        }
        public static void ornekler16() // girilen sayıların aralarındaki tüm asal sayıları bulma
        {
            int k, t, toplam, n1, n2;
            Console.WriteLine("aralık başlangıcı : ");
            n1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Aralık sonu : ");
            n2 = Convert.ToInt32(Console.ReadLine());

            if (n1 <= n2)
            {
                for ( k = n1; k < n2; k++)
                {
                    toplam = 0;
                    for (t = 1; t <= k; t++)
                    {
                        if (k % t == 0)
                        {
                            toplam += t;
                        }   
                    }
                    if (toplam == k + 1)
                    {
                        Console.WriteLine(k);
                    }
                }
            }
                else
                {
                    Console.WriteLine("Geçerli bir aralık giriniz");
                }
            
        }
        public static void ornekler17() // ikilik sayıya dönüştürme
        {
            int sayi;
            Console.WriteLine("Bir tamsayı giriniz : ");
            sayi = Convert.ToInt32(Console.ReadLine());
            for (int bit = 32; bit >= 1; bit--)
            {
                Console.Write("{0}", (sayi >> bit - 1) & 1);
            }
            Console.WriteLine();
        } 
        public static void ornekler18()// copyto ve copy kullanımı
        {
            int[] dizi1 = { 1, 2, 3, 4, 5, 6, 7};
            int[] dizi2 = new int[10];
            int[] dizi3 = new int[10];
            dizi1.CopyTo(dizi2, 2);
            foreach(int i in dizi2)
                Console.Write(i);

            Console.WriteLine();
            Array.Copy(dizi1,2,dizi3,5,3);
            foreach(int a in dizi3)
                Console.Write(a);
            
        }
        public static void ornekler19()
        {
            Array dizi = Array.CreateInstance(typeof(String), 3);
            dizi.SetValue("mehmet",0);
            dizi.SetValue("ahmet",1);
            dizi.SetValue("zafer",2);
            Array.Sort(dizi);
            foreach (string item in dizi)
            {
                Console.WriteLine(item);
            }
        } // Array sıralama
        public static void ornekler20()
        {
            String girilen;
            byte i = 0;
            String[] dizi = new string[i];
            do
            {
                i++;
                Array.Resize(ref dizi,i);
                Console.WriteLine("Kelime giriniz programı durdurmak için sıfıra(0) basınız : ");
                girilen = Convert.ToString(Console.ReadLine());
                if (girilen != "0")
                {
                    dizi.SetValue(girilen,i-1);
                }
                else
                {
                    continue;
                }
                

            } while (girilen != "0");
            Array.Sort(dizi);

            Console.WriteLine(" - - - - - - - - - - - - - - - - -  - - - - - - - - - - - - - - - - - - - - - - - - - -");
            foreach (string item in dizi)
            {
                Console.WriteLine(item);
            }
        } // String kelimeleri sıralama
        public static void ornekler21()
        {
            ArrayList dizi = new ArrayList();
            dizi.Add("saffet");
            dizi.Add(1);
            dizi.Add('s');
            foreach (var item in dizi)
            {
                Console.WriteLine(item);
            }
        } // arraylist kullanımı
        public static void ornekler22(int[] dizi)
        {
            foreach (int i in dizi)
                Console.WriteLine(i);
        }// diziler örnek metodu
        public static void ornekler23()
        {
            Random rnd = new Random();
            int[] dizi = new int[20];
            char[] chars = new char[20];
            for (int i = 0; i < 20; i++)
            {
                dizi[i] = rnd.Next(1,51);
                chars[i] = (char)rnd.Next(20,126);
            }
            for (int i = 0; i < 20; i++)
            {
                Console.WriteLine("{0,2}.değer {1,2}", i, dizi[i]);
                for (int j = 0; j < dizi[i]; j++)
                {
                    Console.Write(chars[i]);
                }
                Console.WriteLine();
            }
        } // dizi random eleman atama
        public static void ornekler24()
        {
            int[][] dizi = new int[3][];
            dizi[0] =new int[] {1,2};
            dizi[1] =new int[] {3,4,5,6,7};
            dizi[2] = new int[] {8,9,0};
            foreach (int[] boyut in dizi)
            {
                foreach  (int item in boyut)
                {
                    Console.Write("{0,3}",item);
                }
                //Console.WriteLine();
            }
        } // düzensiz diziler
        public static void ornekler25() {
            if (BitConverter.IsLittleEndian)
            {
                Console.WriteLine("Little Endian");
            }
            else
            {
                Console.WriteLine("BigEndian");
            }
            int a = 46513;
            Byte[] b = BitConverter.GetBytes(a);
            foreach (var item in b)
            {
                Console.WriteLine(item);
            }
        }
        public static void ornekler26()
        {
            byte[] kaynak = { 1,2,0,1};
            short[] hedef = new short[5];
            Buffer.BlockCopy(kaynak,0,hedef,0,4);
            foreach (short item in hedef)
            {
                Console.Write(item+" ");
            }
            Console.WriteLine("\n"+Buffer.GetByte(hedef,0));
            Buffer.SetByte(hedef,5,3);
            foreach (short item in hedef)
            {
                Console.Write(item+" ");
            }
            Console.WriteLine();
            Console.WriteLine(Buffer.ByteLength(hedef));
            Console.WriteLine(Buffer.ByteLength(kaynak));
        }
    }
}
