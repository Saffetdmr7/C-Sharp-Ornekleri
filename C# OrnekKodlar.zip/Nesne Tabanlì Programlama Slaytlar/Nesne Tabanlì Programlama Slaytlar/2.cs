﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nesne_Tabanlı_Programlama_Slaytlar
{
    internal class _2
    {
    }
    class Dortgen
    {
        public static int En = 20; public static int Boy = 5;
        public static int Alan()
        { int Alan = En * Boy; return Alan; }
        public static void dondur()
        {
            Console.WriteLine("***************");
            Console.WriteLine("En:{0,5}", En);
            Console.WriteLine("Boy:{0,5}", Boy);
            Console.WriteLine("Alan:{0,5}", Alan());
            Console.WriteLine("***************");
        }
    }

    class Dortgen1
    {
        int En;
        int Boy;
        public static void dondur()
        {
            int En = 50; int Boy = 100;
            Console.WriteLine(En + "\n" + Boy);
        }
    }
    class Dortgen2
    {
        static int En = 8;
        static int Boy = 7;
        public static void dondur()
        {
            En = 50; Boy = 100;
            Console.WriteLine(En + "\n" + Boy);
        }
    }
    class yazdegistir
    {
        public static void degistir(int[] dizi)
        {
            for (int i = 0; i < dizi.Length; i++)
            {
                dizi[i] = 10;
            }
        }
        public static void yaz(Array dizi)
        {
            foreach (dynamic item in dizi)
            {
                Console.WriteLine(item);
            }
        }

    }
    class yazdegistir2
    {
        public static void degistir(ref int sayı)
        {
            sayı = 100;
            //Console.WriteLine(sayı);
        }
        public static void yaz(int sayı)
        {
            Console.WriteLine(sayı);
        }

    }
}


