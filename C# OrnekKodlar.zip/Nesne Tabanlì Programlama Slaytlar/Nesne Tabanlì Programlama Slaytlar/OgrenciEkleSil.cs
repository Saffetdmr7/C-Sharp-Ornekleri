﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nesne_Tabanlı_Programlama_Slaytlar
{
    internal class OgrenciEkleSil
    {
        static ArrayList ogrenciList = new ArrayList();
        public static void Islemler()
        {
            Console.WriteLine("Aşağıdaki işlemlerlerden birini seçiniz");
            Console.WriteLine("******************");
            Console.WriteLine("1-Ögrenciyi ekle");
            Console.WriteLine("2-Ögrenciyi sil");
            Console.WriteLine("3-Bütün ögrencileri listele");
            Console.WriteLine("4-Kayıtlı öğrencilerin sayısını Göster");
            Console.WriteLine("5-bütün öğrencilerin not ortalamasını hesapla");
            Console.WriteLine("0-Kapat");
            Boolean durdur = true;
            do
            {    
                    byte i = 0;
                    yeniden:
                    try
                    {
                        i = Convert.ToByte(Console.ReadLine());
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    goto yeniden;
                    }
                    
                    switch (i)
                    {
                        case 0:
                            durdur = false;
                            break;
                        case 1:
                            AddOgr();
                            Console.WriteLine("Yeni Bir İşlem Giriniz");
                        break;
                        case 2:
                            removeOgr();
                            Console.WriteLine("Yeni Bir İşlem Giriniz");
                        break;
                        case 3:
                            ListOgr();
                            Console.WriteLine("Yeni Bir İşlem Giriniz");
                        break;
                        case 4:
                            Allogr();
                            Console.WriteLine("Yeni Bir İşlem Giriniz");
                        break;
                        case 5:
                            GradeOgrAll();
                            Console.WriteLine("Yeni Bir İşlem Giriniz");
                        break;
                        default:
                            Console.WriteLine("Lütfen belirtilen aralıktaki herhangi bir sayıyı giriniz");
                    goto yeniden;
                    }
            } while (durdur);
            

        }
        public struct Ogrenci
        {
            public int number;
            public string name;
            public string surname;
            public byte grade;
            // Encapsulation
            public Ogrenci(string name, string surname, int number, byte grade)
            {
                this.name = name;
                this.surname = surname;
                this.number = number;
                this.grade = grade;
            }
        }
        private static void AddOgr()
        {
            Console.Write("Adınız = ");
            string name = Console.ReadLine();
            name.ToLower();
            Console.Write("Soyadınız = ");
            string surname = Console.ReadLine();
            surname.ToLower();
            Console.Write("Numaranız = ");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.Write("Aldığınız Not = ");
            byte grade = Convert.ToByte(Console.ReadLine());
            Ogrenci ogrNesne = new Ogrenci(name,surname,number,grade);
            ogrenciList.Add(ogrNesne);
        }
        private static void removeOgr()
        {
            
            Console.Write("Silinecek öğrencinin numarasını giriniz = ");
            String isim = Console.ReadLine();
            isim.ToLower();
            String isim2 = "";
            foreach (Ogrenci a in ogrenciList)
            {
                isim2 = a.name.ToLower();
                if (isim2.Equals(isim))
                {
                    Console.WriteLine("Başarılı");
                    ogrenciList.RemoveRange(ogrenciList.IndexOf(a), 1);
                    break;
                }
            }
        
        }
        private static void ListOgr()
        {
            byte x = 1;
            foreach (Ogrenci a in ogrenciList)
            {
                Console.WriteLine("{0} Öğrencinin Adı: {1} Soyadı: {2} Numarası: {3} Notu: {4} dur",x,a.name,a.surname,a.number,a.grade);
                x++;
            }
            
        }
        
        private static void Allogr()
        {
            byte x = 0;
            foreach (Ogrenci item in ogrenciList)
            {
                x++;
            }
            Console.WriteLine(x);
        }

        private static void GradeOgrAll()
        {
            byte x = 0;
            double ortalama = 0;
            foreach (Ogrenci a in ogrenciList)
            {
                ortalama += a.grade;
                x++;
            }
            ortalama = ortalama / x;
            Console.WriteLine("Ortalama = {0}",ortalama);
        }
    }

    
}