﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Nesne_Tabanlı_Programlama_Slaytlar
{
    internal class Ogrenci
    {
        public ulong OgrenciNo;
        public string Ad;
        public string Soyad;
        public string Bolum;
        public byte Sinif;
    }
   public class Program
    {
        public void Olustur()
        {
            Ogrenci ogrenci = new Ogrenci();
            Console.WriteLine(ogrenci.Ad);
            Console.WriteLine(ogrenci.Soyad);
            Console.WriteLine(ogrenci.Sinif);
            Console.WriteLine(ogrenci.OgrenciNo);
            Console.WriteLine(ogrenci.Bolum);
        }
    }
    public class KrediHesabi
    {
        public ulong HesapNo;
    }
    

}
