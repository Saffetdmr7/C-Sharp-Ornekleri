﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Ntpodevler
{
    internal class Program
    {
    }
    class Uygulama1
    {
        public static void Main(string[] args)
        {
            //Console.WriteLine("Uygulama 1 \n");
            //soru1();
            //soru2();
            //soru3();
            //soru4();
            //soru5();
            //Console.WriteLine("----------------------------------");
            //Console.WriteLine("Uygulama 2 \n");
            //uygulama2.soru1();
            //uygulama2.soru2();
            //uygulama2.soru3();
            //uygulama2.soru4();
            //uygulama2.soru5();
            //Console.WriteLine("----------------------------------");
            //Console.WriteLine("Uygulama 3 \n");
            //Console.WriteLine("Bir Tamsayı giriniz : ");
            //int sayi1 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Bir Tamsayı Daha giriniz : ");
            //int sayi2 = Convert.ToInt32(Console.ReadLine());
            //uygulama3.uygulama3soru(sayi1, sayi2);
            //Console.WriteLine("----------------------------------");
            //Console.WriteLine("Uygulama 4 \n");
            //Console.WriteLine("gg.aa.yyyy cinsinden tarih giriniz : ");
            //String tarih = Console.ReadLine();
            //uygulama4.uygulama4soru(tarih);
            //Console.WriteLine("----------------------------------");
            //Console.WriteLine("Uygulama 4 \n");
            //Console.WriteLine("İki Dereceli Bir Denklemde : ");
            //Console.WriteLine("X^2 nin katsayısını giriniz : ");
            //int a = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("X in Katsayısını giriniz : ");
            //int b = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Sabit Sayıyı Giriniz : ");
            //int c = Convert.ToInt32(Console.ReadLine());
            //uygulama5.uygulama5soru(a, b, c);
            Console.WriteLine("----------------------------------");
            Console.WriteLine("Uygulama 4 \n");
            Console.WriteLine("Derece griniz : ");
            int derece = Convert.ToInt32(Console.ReadLine());
            uygulama6.uygulama6soru(derece);

            Console.ReadLine();
        }

        public static void soru1()
        {
            double sonuc = 48 / 6 / 4;
            Console.WriteLine("Soru1 sonucu = " + sonuc);
        }
        public static void soru2()
        {
            double sonuc = 24 / 3 * 2;
            Console.WriteLine("Soru2 sonucu = " + sonuc);
        }
        public static void soru3()
        {
            double sonuc = (Math.Pow(2, 2)) + 5 - 1 + 4;
            Console.WriteLine("Soru3 sonucu = " + sonuc);
        }
        public static void soru4()
        {
            double sonuc = (7 + 4) * 2 - 1 + 8 / 2;
            Console.WriteLine("Soru4 sonucu = " + sonuc);
        }
        public static void soru5()
        {
            double sonuc = (5 - 1) * 2 - 1 + (Math.Pow(7, 2)) / 2;
            Console.WriteLine("Soru5 sonucu = " + sonuc);
        }
    }
    public class uygulama2
    {
        static int x = 20;
        static int y = 13;
        static int z = 42;

        public static void soru1()
        {
            Boolean ifade = (23 == 55 && 76 > 45 && 5 < 12);
            Console.WriteLine("Soru1 sonucu = " + ifade);

        }
        public static void soru2()
        {
            Boolean ifade = (23 >= 23 && 45 != 18);
            Console.WriteLine("Soru2 sonucu = " + ifade);
        }
        public static void soru3()
        {
            Boolean ifade = (x > y && z == y && z < x);
            Console.WriteLine("Soru3 sonucu = " + ifade);
        }
        public static void soru4()
        {
            Boolean ifade = (z > x && y < x);
            Console.WriteLine("Soru4 sonucu = " + ifade);
        }
        public static void soru5()
        {
            Boolean ifade = (x != z || y <= z);
            Console.WriteLine("Soru5 sonucu = " + ifade);
        }
    }
    public class uygulama3
    {
        public static void uygulama3soru(int sayi, int sayi2)
        {
            if (sayi % sayi2 == 0 || sayi2 % sayi == 0)
            {
                Console.WriteLine("Uygulama3 sonucu : Tam bölünür");
            }
            else
            {
                Console.WriteLine("Uygulama3 sonucu : Tam Bölünmez");
            }
        }
    }
    public class uygulama4
    {
        public static void uygulama4soru(String tarih)
        {
            String a;
            int b;
            //gg.aa.yyyy

            if (tarih.Substring(0, 2).Contains("."))
            {
                tarih = tarih.Insert(0, "0");

            }
            if (tarih.Substring(3, 2).Contains("."))
            {
                a = tarih.Substring(3, 1);
                tarih = tarih.Insert(3, "0");
                b = Convert.ToInt32(a);

            }
            else {
                a = tarih.Substring(3, 2);
                b = Convert.ToInt32(a);
            }
            Console.WriteLine(tarih);
            if (tarih.Length < 11)
            {
                if (Convert.ToInt32(tarih.Substring(0, 2)) < 31 && Convert.ToInt32(tarih.Substring(0, 2)) > 0 && Convert.ToInt32(tarih.Substring(3, 2)) < 13 && Convert.ToInt32(tarih.Substring(3, 2)) > 0 && Convert.ToInt32(tarih.Substring(6, 4)) > 0)
                {
                    switch (b)
                    {
                        case 1:
                            Console.WriteLine(aylar.Ocak);
                            break;
                        case 2:
                            Console.WriteLine(aylar.Şubat);
                            break;
                        case 3:
                            Console.WriteLine(aylar.Mart);
                            break;
                        case 4:
                            Console.WriteLine(aylar.Nisan);
                            break;
                        case 5:
                            Console.WriteLine(aylar.Mayıs);
                            break;
                        case 6:
                            Console.WriteLine(aylar.Haziran);
                            break;
                        case 7:
                            Console.WriteLine(aylar.Temmuz);
                            break;
                        case 8:
                            Console.WriteLine(aylar.Ağustos);
                            break;
                        case 9:
                            Console.WriteLine(aylar.Eylül);
                            break;
                        case 10:
                            Console.WriteLine(aylar.Ekim);
                            break;
                        case 11:
                            Console.WriteLine(aylar.Kasım);
                            break;
                        case 12:
                            Console.WriteLine(aylar.Aralık);
                            break;
                        default:
                            Console.WriteLine("Lütfen 1 ile 12 arasında bir değer giriniz.");
                            break;

                    }

                }
                else
                {
                    Console.WriteLine("Geçersiz bir değer girdiniz lütfen kontrol ediniz");
                }
            }
            else
            {
                Console.WriteLine("Geçersiz bir değer girdiniz lütfen kontrol ediniz");
            }


        }

    }
    public class uygulama5
    {
        public static void uygulama5soru(int a, int b, int c)
        {
            Console.WriteLine("{0}X^2+{1}X+{2} Denkleminde", a, b, c);
            double kok1;
            double kok2;
            double delta = Math.Pow(b, 2) - (4 * a * c);
            if (delta > 0)
            {
                kok1 = ((-b) - (Math.Sqrt(delta))) / (2 * a);
                kok2 = ((-b) + (Math.Sqrt(delta))) / (2 * a);
                Console.WriteLine("iki Kök Vardır");
                Console.WriteLine("Birinci Kök = {0}", kok1);
                Console.WriteLine("İkinci Kök = {0}", kok2);
            }
            else if (delta == 0)
            {
                kok1 = ((-b) - (Math.Sqrt(delta))) / (2 * a);
                Console.WriteLine("tek Kök Vardır");
                Console.WriteLine("Kök = {0}", kok1);
            }
            else
            {
                Console.WriteLine(" Kökü Yoktur");
            }
        }

    }
    public class uygulama6{
            public static void uygulama6soru(int derece)
        {
            if (derece >= 0)
            {
                double radyan = derece / 180;
                Console.WriteLine("Sonuc = {0} ", radyan);
            }
            else
            {
                Console.WriteLine("Negatif olamaz derece");
            }
        }
        }

public enum aylar
    {
        Ocak = 1,Şubat,Mart,Nisan,Mayıs,Haziran,Temmuz,Ağustos,Eylül,Ekim,Kasım,Aralık
    }
}