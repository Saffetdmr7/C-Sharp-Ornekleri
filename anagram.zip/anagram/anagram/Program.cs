﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace anagram
{
    public class anagram {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Programa hoşgeldiniz");
            Console.WriteLine("Programı durdurmak için 1 e basınız !!!");
            do
            {
                ArrayList kelime1 = new ArrayList();
                ArrayList kelime2 = new ArrayList();
                Console.WriteLine("Bir kelime giriniz :");
                string ilkKelime = Console.ReadLine();
                if (ilkKelime.Equals("1"))
                {   
                    break;
                }
                Console.WriteLine("İkinci kelimeyi giriniz :");
                string ikinciKelime = Console.ReadLine();
                if (ikinciKelime.Equals("1"))
                {
                    break;
                }
                ilkKelime.Trim();
                ikinciKelime.Trim();
                if (!(ilkKelime.Length == ikinciKelime.Length))
                {
                    Console.WriteLine("Eleman sayıları aynı olmalıdır.");
                    continue;
                }
                foreach (char karakter in ilkKelime.ToCharArray())
                {
                    kelime1.Add(karakter);
                }
                foreach (char karakter in ikinciKelime.ToCharArray())
                {
                    kelime2.Add(karakter);
                }
                for (int i = 0; i < kelime2.Count; i++)
                {
                    if (kelime1.Contains(kelime2[i]))
                    {
                        kelime1.Remove(kelime2[i]);
                    }
                    else
                    {
                        break;
                    }
                }
                if (kelime1.Count == 0)
                {
                    Console.WriteLine("Kelimeler Anagramdır.");
                }
                else
                {
                    Console.WriteLine("Kelimeler Anagram değildir.");
                }
            } while (true);
        }     
    }
}